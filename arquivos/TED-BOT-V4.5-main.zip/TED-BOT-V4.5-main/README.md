<img src="https://readme-typing-svg.herokuapp.com/?font=mono&size=30&duration=4000&color=00008b&center=falso&vCenter=falso&lines=🜛+𝐓𝐄𝐃-𝐁𝐎𝐓-𝐕4.5+🜛;۞+𝙊𝙁𝘾+𝙐𝙋𝘿𝘼𝙏𝙀+۞;@𝙏𝙚𝙙𝙯𝙞𝙣𝙝𝙤">      

<h1 align="center">
<p>
<img src= "https://xatimg.com/image/hmvsfHIhqL9r.jpg" alt="𝐓𝐄𝐃 𝐁𝐎𝐓 𝐕4.5" width="720">
</p>

<p align="center">
<a href="#"><img title="BOT-MULTI-DEVICE" src="https://img.shields.io/badge/BOT•MULTI•DEVICE-blue?&style=for-the-badge"></a>
</p>

<p align="center">
<img title="Autor" src="https://img.shields.io/badge/Autor-@tedzinho_-orange.svg?style=for-the-badge&logo=github"></a>
<img title="Versão" src="https://img.shields.io/badge/Versão-4.5.0-orange.svg?style=for-the-badge&logo=github"></a>
</p>

## Instalação Via Termux  <img src="https://user-images.githubusercontent.com/108157095/182052725-6568419a-6a9f-490a-85ea-90b94af694fe.png" height="25px">
**1° Comando**
```
apt-get update -y && pkg upgrade -y && pkg update -y && pkg install nodejs -y && pkg install nodejs-lts -y && pkg install ffmpeg -y && pkg install wget -y && pkg install tesseract -y && pkg install git -y
```
**ATENÇÃO:**
Será necessário digitar y toda vez que pedir a caixa [y/n]
---------------------------

**2° Comando**
```
termux-setup-storage
```
**3° Comando**
```
cd /sdcard/Download && git clone https://github.com/Tedzinho40/TED-BOT-V4.5
```
**4° Comando**
```
cd /storage/emulated/0/Download/TED-BOT-V4.5 && npm start
```

## 💾 START DO BOT 💾 <img src="https://user-images.githubusercontent.com/108157095/182053901-78e4a217-51ba-42a3-8ec5-38ed978ad752.png" height="25px">
```
npm start
```

<img src="https://readme-typing-svg.herokuapp.com/?font=mono&size=30&duration=4000&color=00008b&center=falso&vCenter=falso&lines=╰•★𝐓𝐄𝐃-𝐁𝐎𝐓-𝐕4.5★•╯"> 